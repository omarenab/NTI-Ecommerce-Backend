const About = require("../models/About");

const fs = require("node:fs")

 const getAbout = async (req, res) => {
  try {
    const about = await About.findOne();
    res.status(200).json(about);
  } catch (err) {
    res.status(500).json({ error: "Failed to Fetch data", message: err.message });
  }
};

 const updateAbout = async (req, res) => {
  try {
    const { profileImage: previousImage } = await About.findOne();
    if (fs.existsSync(`./assets/${previousIamge}`)) {
      fs.rm(`./assets/${previousImage}`, (err) => {
        if (err) {
          console.log(`Error Deleting Image: ${err}`);
        }
      });
    }
    const { title, description } = req.body;
    const profileImage = req.file.filename;
    const about = await About.findByIdAndUpdate(
      "68dc36bdf858e2078faa6c8f",
      { title, description, profileImage },
      { new: true }
    );
    res.status(200).json(about);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {getAbout,updateAbout}