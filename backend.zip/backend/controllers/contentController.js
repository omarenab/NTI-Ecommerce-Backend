
const Content = require ('../models/Content')



 const getContent = async (req, res) => {
  try {
    res.status(200).json(await Content.findOne());
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

 const updateContent = async (req, res) => {
  try {
    const { header_input, routeNames, footer_input } = req.body;
    const content = await Content.findByIdAndUpdate(
      "",
      { header_input, routeNames, footer_input },
      { new: true }
    );
    res.status(200).json(content);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

module.exports = {getContent,updateContent}

