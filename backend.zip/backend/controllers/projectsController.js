const fs = require("node:fs");
const Projects = require("../models/Projects");

const getProjects =  async (req, res) => {
  try {
    res.status(200).json(await Projects.find());
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

 const addProject =  async (req, res) => {
  try {
    const {
      title,
      description,
      techStack,
      githubLink,
      LinkButton,
      category
    } = req.body;
    const projectImage = req.file.filename;
    const project = await Projects.create({
      title,
      description,
      techStack,
      githubLink,
      projectImage,
      LinkButton,
      category
    });
    res.status(200).json(project);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

 const updateProject =  async (req, res) => {
  try {
    const { projectImage: prevImage } = await Projects.findOne({
      _id: req.params.id,
    });
    if (fs.existsSync(`./assets/${prevImage}`)) {
      fs.rm(`./assets/${prevImage}`, (err) => {
        if (err) {
          console.log(`Error in Deleting Previous Image: ${err}`);
        }
      });
    }
    const {
      title,
      description,
      techStack,
      githubLink,
      LinkButton,
      category
    } = req.body;
    const projectImage = req.file.filename;
    const project = await Projects.findByIdAndUpdate(
      req.params.id,
      {
        title,
        techStack,
        description,
        githubLink,
        projectImage,
        LinkButton,
        category
      },
      { new: true }
    );
    res.status(200).json(project);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

 const deleteProject =  async (req, res) => {
  try {
    const project = await Projects.findByIdAndDelete(req.params.id);
    if (fs.existsSync(`./assets/${project.projectImage}`)) {
      fs.rm(`./assets/${project.projectImage}`, (err) => {
        if (err) {
          console.log(`Error in Deleting Previous Image: ${err}`);
        }
      });
    }
    res.status(200).json(project);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
}

module.exports= {getProjects,addProject,updateProject,deleteProject}

