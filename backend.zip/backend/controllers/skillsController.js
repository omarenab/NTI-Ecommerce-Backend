const fs = require("node:fs");
const Skills = require("../models/Skills");

 const getSkills = async (req, res) => {
  try {
    res.status(200).json(await Skills.find());
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
// POST
const addSkill = async (req, res) => {
  try {
    const { title, description, percentage } = req.body;
    const icon = req.file.filename;
    const skill = await Skills.create({ title, description, icon, percentage });
    res.status(200).json(skill);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

 const updateSkill = async (req, res) => {
  try {
    const { icon: prevIcon } = await Skills.findOne({
      _id: req.params.id,
    });
    if (fs.existsSync(`./assets/${prevIcon}`)) {
      fs.rm(`./assets/${prevIcon}`, (err) => {
        if (err) {
          console.log(`Error  Deleting Icon ${err}`);
        }
      });
    }
    const { title, description, percentage } = req.body;
    const icon = req.file.filename;
    const skill = await Skills.findByIdAndUpdate(
      req.params.id,
      { title, description, percentage, icon },
      { new: true }
    );
    res.status(200).json(skill);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

const removeSkill = async (req, res) => {
  try {
    const skill = await Skills.findByIdAndDelete(req.params.id);
    if (fs.existsSync(`./assets/${skill.icon}`)) {
      fs.rm(`./assets/${skill.icon}`, (err) => {
        if (err) {
          console.log(`Error  Deleting  Icon: ${err}`);
        }
      });
    }
    res.status(200).json(skill);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
module.exports = {getSkills,addSkill,updateSkill,removeSkill}

