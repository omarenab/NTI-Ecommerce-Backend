const mongoose = require("mongoose");
const validator = require("validator");

const contactSchema = new mongoose.Schema(
  {
    name_input: { type: String, trim: true },
    email_input: {
      type: String,
      required: true,
      lowercase: true,
      validate: {
        validator: (value) => validator.isEmail(value),
        message: "Please enter a valid email",
      },
    },
    phone_input: { type: String, required: true },
    message_input: { type: String, required: true },
    button_input: { type: String, trim: true },

    createdAt: { type: Date, default: Date.now },
  },
  { versionKey: false }
);

module.exports = mongoose.model("Contact", contactSchema);
