// SETUP DB
const mongoose = require("mongoose");

const routesNamesSchema = mongoose.Schema({
  home: String,
  skills: String,
  projects: String,
  contact: String,
  about: String,
});
const contentSchema = mongoose.Schema(
  {
    header_input: {
      type: String,
      trim: true,
    },
    routeNames: {
      type: routesNamesSchema,
    },
    footer_input: {
      type: String,
      trim: true,
    },
  },
  {
    versionKey: false,
  }
);

// EXPORTS MODEL
const ContentModel = mongoose.model("Content", contentSchema);
module.exports = ContentModel;
