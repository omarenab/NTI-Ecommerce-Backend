const mongoose = require("mongoose");

const homeSchema = new mongoose.Schema({
  headline: { type: String, required: true },
  description: { type: String, required: true },
  profileImage: { type: String },
  resumeButtonInput: { type: String },
  contactButtonInput: { type: String },

  socialLinks: [
    {
      platform: { type: String, required: true },
      url: { type: String, required: true },
      icon: { type: String },
    },
  ],
});
module.exports = mongoose.model("Home", homeSchema);
