const mongoose = require('mongoose')

const projectSchema = new mongoose.Schema({ 
  title: { type: String, required: true },          
  description: { type: String, required: true , trim : true},     
  projectImage: { type: String, trim : true },                           
  techStack: [{ type: String , trim : true}],                     
  githubLink: { type: String , trim : true},
  LinkButton : {type : String , trim : true},                         
  category: { type: String , trim : true},                       
  createdAt: { type: Date, default: Date.now }});

  module.exports = mongoose.model("Projects",projectSchema)