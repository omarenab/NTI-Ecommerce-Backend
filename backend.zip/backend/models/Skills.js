const mongoose = require("mongoose");

const skillSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, trim: true },
    icon: { type: String, trim: true },
    percentage: { type: Number, min: 0, max: 100 },
  },
  { versionKey: false }
);

module.exports = mongoose.model("Skills", skillSchema);
