const express = require("express");
const router = express.Router();
const {
  getMessages,
  addMessage,
  removeMessage,
} = require("../controllers/messagesController");

router.get("/", getMessages);
router.post("/", addMessage);
router.delete("/:id", removeMessage);

module.exports = router;
