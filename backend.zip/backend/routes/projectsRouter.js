const express = require("express");
const router = express.Router();
const upload = require('../middlewares/upload.middleware')

const { getProjects, updateProject, addProject, deleteProject } = require("../controllers/projectsController");

router.get("/", getProjects);
router.post("/",upload.single("projectImage"), addProject)
router.put("/:id",upload.single("projectImage") ,updateProject);
router.delete("/:id", deleteProject)

module.exports = router;
