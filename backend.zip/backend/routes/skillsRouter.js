const express = require("express");
const router = express.Router();
const upload = require("../middlewares/upload.middleware");

const {
  getSkills,
  updateSkill,
  removeSkill,
  addSkill,
} = require("../controllers/skillsController");

router.get("/", getSkills);
router.post("/", addSkill);
router.put("/:id", upload.single("icon"), updateSkill);
router.delete("/:id", upload.single("icon"), removeSkill);

module.exports = router;
