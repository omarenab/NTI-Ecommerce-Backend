const dotenv = require("dotenv");
const cors = require("cors");
const http = require("http")
dotenv.config();
const express = require("express");
const mongoose = require("mongoose");
const homeRouter = require("./routes/homeRouter.js");
const contactRouter = require("./routes/contactRouter.js");
const aboutRouter = require("./routes/aboutRouter.js");
const projectsRouter = require("./routes/projectsRouter.js");
const messagesRouter = require("./routes/messagesRouter.js");
const skillsRouter = require("./routes/skillsRouter.js");
const contentRouter = require("./routes/contentRouter.js");

const path = require("node:path");

const app = express();
app.use(express.json());
app.use(cors());
app.use("/assets", express.static(path.join(__dirname, "../assets")));

app.use("/home", homeRouter);
app.use("/about", aboutRouter);
app.use("/contact", contactRouter);
app.use("/projects", projectsRouter);
app.use("/messages", messagesRouter);
app.use("/skills", skillsRouter);
app.use("/content", contentRouter);

mongoose
  .connect(process.env.MONGO_URI)
  .then(() => console.log("DataBase Connected Successfully"))
  .catch((err) => console.log(`Error in connection ${err}`));

  const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
  console.log(`server running on port ${PORT}`);
 
});

